import * as tf from '@tensorflow/tfjs';
import { Dataset, ModelMetrics, PredictionResult, TrainingExample } from '../types';

// Preprocessing constants
const MAX_VOCAB_SIZE = 1000;
const MAX_SEQ_LENGTH = 20;

class TextClassifier {
  private model: tf.LayersModel | null = null;
  private tokenizer: Map<string, number> = new Map();
  private labelMap: Map<string, number> = new Map();
  private reverseLabelMap: Map<number, string> = new Map();
  private vocabSize: number = 0;
  private metrics: ModelMetrics[] = [];
  private isTraining: boolean = false;

  // Create vocabulary from dataset
  private createVocabulary(texts: string[]): void {
    const tokenFreq = new Map<string, number>();
    
    // Count token frequencies
    texts.forEach(text => {
      const tokens = this.tokenize(text);
      tokens.forEach(token => {
        tokenFreq.set(token, (tokenFreq.get(token) || 0) + 1);
      });
    });
    
    // Sort by frequency
    const sortedTokens = [...tokenFreq.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, MAX_VOCAB_SIZE - 1) // Reserve 0 for OOV
      .map(entry => entry[0]);
    
    // Create vocabulary map
    this.tokenizer = new Map();
    sortedTokens.forEach((token, i) => {
      this.tokenizer.set(token, i + 1); // Start from 1, 0 is for OOV
    });
    
    this.vocabSize = this.tokenizer.size + 1; // +1 for OOV
  }

  // Tokenize text into words
  private tokenize(text: string): string[] {
    return text.toLowerCase()
      .replace(/[^\w\s]/g, '')
      .split(/\s+/)
      .filter(t => t.length > 0);
  }

  // Convert text to sequence
  private textToSequence(text: string): number[] {
    const tokens = this.tokenize(text);
    return tokens.map(token => this.tokenizer.get(token) || 0) // 0 for OOV
      .slice(0, MAX_SEQ_LENGTH);
  }

  // Pad sequences to fixed length
  private padSequences(sequences: number[][]): number[][] {
    return sequences.map(seq => {
      if (seq.length >= MAX_SEQ_LENGTH) {
        return seq.slice(0, MAX_SEQ_LENGTH);
      }
      return [...seq, ...Array(MAX_SEQ_LENGTH - seq.length).fill(0)];
    });
  }

  // Create and compile model
  private createModel(numClasses: number): tf.LayersModel {
    const model = tf.sequential();
    
    model.add(tf.layers.embedding({
      inputDim: this.vocabSize,
      outputDim: 50,
      inputLength: MAX_SEQ_LENGTH
    }));
    
    model.add(tf.layers.globalAveragePooling1d({}));
    
    model.add(tf.layers.dense({
      units: 64,
      activation: 'relu'
    }));
    
    model.add(tf.layers.dropout({ rate: 0.5 }));
    
    model.add(tf.layers.dense({
      units: numClasses,
      activation: 'softmax'
    }));
    
    model.compile({
      optimizer: 'adam',
      loss: 'categoricalCrossentropy',
      metrics: ['accuracy']
    });
    
    return model;
  }

  // Prepare data for training
  private prepareTrainingData(dataset: Dataset): [tf.Tensor2D, tf.Tensor2D] {
    const { examples, categories } = dataset;
    
    // Create label mapping
    this.labelMap = new Map();
    this.reverseLabelMap = new Map();
    categories.forEach((category, i) => {
      this.labelMap.set(category, i);
      this.reverseLabelMap.set(i, category);
    });
    
    // Extract texts and labels
    const texts = examples.map(ex => ex.text);
    const labels = examples.map(ex => this.labelMap.get(ex.label) || 0);
    
    // Create vocabulary
    this.createVocabulary(texts);
    
    // Convert texts to sequences
    const sequences = texts.map(text => this.textToSequence(text));
    const paddedSequences = this.padSequences(sequences);
    
    // Convert to tensors
    const xs = tf.tensor2d(paddedSequences, [paddedSequences.length, MAX_SEQ_LENGTH]);
    
    // One-hot encode labels
    const ys = tf.oneHot(tf.tensor1d(labels, 'int32'), categories.length);
    
    return [xs, ys];
  }

  // Train the model
  async train(dataset: Dataset, epochs: number = 50, callbacks: any = {}): Promise<void> {
    if (this.isTraining) {
      throw new Error('Model is already training');
    }

    this.isTraining = true;
    this.metrics = [];

    try {
      // Prepare data
      const [xs, ys] = this.prepareTrainingData(dataset);
      
      // Create model
      this.model = this.createModel(dataset.categories.length);
      
      // Train model
      await this.model.fit(xs, ys, {
        epochs,
        validationSplit: 0.2,
        shuffle: true,
        callbacks: {
          onEpochEnd: (epoch, logs) => {
            const metrics: ModelMetrics = {
              epoch,
              accuracy: logs?.acc || 0,
              loss: logs?.loss || 0
            };
            this.metrics.push(metrics);
            
            if (callbacks.onProgress) {
              callbacks.onProgress(metrics);
            }
          }
        }
      });
      
      // Cleanup tensors
      xs.dispose();
      ys.dispose();
      
      if (callbacks.onComplete) {
        const finalMetrics = this.metrics[this.metrics.length - 1];
        callbacks.onComplete(finalMetrics);
      }
    } catch (error) {
      console.error('Training error:', error);
      if (callbacks.onError) {
        callbacks.onError(error);
      }
    } finally {
      this.isTraining = false;
    }
  }

  // Predict label for new text
  async predict(text: string): Promise<PredictionResult | null> {
    if (!this.model || !this.tokenizer || this.labelMap.size === 0) {
      return null;
    }
    
    // Convert text to sequence
    const sequence = this.textToSequence(text);
    const paddedSequence = this.padSequences([sequence]);
    
    // Predict
    const input = tf.tensor2d(paddedSequence, [1, MAX_SEQ_LENGTH]);
    const prediction = this.model.predict(input) as tf.Tensor;
    const confidences = await prediction.data();
    
    // Clean up tensors
    input.dispose();
    prediction.dispose();
    
    // Get predicted label and confidence
    const maxIndex = Array.from(confidences).indexOf(Math.max(...Array.from(confidences)));
    const predictedLabel = this.reverseLabelMap.get(maxIndex) || '';
    
    // Format all predictions
    const allPredictions = Array.from(confidences).map((confidence, i) => ({
      label: this.reverseLabelMap.get(i) || '',
      confidence: confidence
    }));
    
    return {
      text,
      predictedLabel,
      confidence: confidences[maxIndex],
      allPredictions
    };
  }

  // Get training metrics
  getMetrics(): ModelMetrics[] {
    return this.metrics;
  }
  
  // Get last metric (current model performance)
  getCurrentMetrics(): ModelMetrics | null {
    if (this.metrics.length === 0) {
      return null;
    }
    return this.metrics[this.metrics.length - 1];
  }
  
  // Check if model is trained
  isTrained(): boolean {
    return this.model !== null;
  }
  
  // Get vocabulary size
  getVocabularySize(): number {
    return this.vocabSize;
  }
  
  // Save the model to browser storage
  async saveModel(name: string): Promise<void> {
    if (!this.model) {
      throw new Error('No model to save');
    }
    
    // Save model architecture and weights
    const modelInfo = {
      name,
      architecture: this.model.toJSON(),
      tokenizer: Array.from(this.tokenizer.entries()),
      labelMap: Array.from(this.labelMap.entries()),
      metrics: this.metrics
    };
    
    localStorage.setItem(`model_${name}`, JSON.stringify(modelInfo));
  }
  
  // Load a model from browser storage
  async loadModel(name: string): Promise<boolean> {
    const modelInfoStr = localStorage.getItem(`model_${name}`);
    if (!modelInfoStr) {
      return false;
    }
    
    try {
      const modelInfo = JSON.parse(modelInfoStr);
      
      // Reconstruct model
      this.model = await tf.models.modelFromJSON(modelInfo.architecture);
      
      // Reconstruct tokenizer and label maps
      this.tokenizer = new Map(modelInfo.tokenizer);
      this.labelMap = new Map(modelInfo.labelMap);
      this.reverseLabelMap = new Map(
        Array.from(this.labelMap.entries()).map(([k, v]) => [v, k])
      );
      
      this.vocabSize = this.tokenizer.size + 1;
      this.metrics = modelInfo.metrics || [];
      
      return true;
    } catch (error) {
      console.error('Error loading model:', error);
      return false;
    }
  }
}

export default new TextClassifier();