import React, { useState, useEffect } from 'react';
import { Brain, Cpu, Database, TestTube } from 'lucide-react';
import * as tf from '@tensorflow/tfjs';
import Header from './components/Header';
import DatasetManager from './components/DatasetManager';
import ModelTrainer from './components/ModelTrainer';
import ModelTester from './components/ModelTester';
import { Dataset } from './types';
import { sampleDataset } from './data/sampleDataset';
import modelService from './services/modelService';

// Initialize TensorFlow.js
tf.setBackend('webgl');

function App() {
  const [isInitialized, setIsInitialized] = useState(false);
  const [dataset, setDataset] = useState<Dataset>(sampleDataset);
  const [modelTrained, setModelTrained] = useState(false);
  const [activeTab, setActiveTab] = useState<'dataset' | 'train' | 'test'>('dataset');

  // Initialize TensorFlow.js backend
  useEffect(() => {
    const initTF = async () => {
      try {
        await tf.ready();
        setIsInitialized(true);
        console.log('TensorFlow.js initialized with backend:', tf.getBackend());
      } catch (error) {
        console.error('Failed to initialize TensorFlow.js:', error);
      }
    };
    
    initTF();
  }, []);

  const handleDatasetChange = (updatedDataset: Dataset) => {
    setDataset(updatedDataset);
    // If dataset changes significantly, model might need retraining
    if (modelTrained) {
      setModelTrained(false);
    }
  };

  const handleModelTrained = () => {
    setModelTrained(true);
    setActiveTab('test');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="mb-6 text-center">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Text Classification Trainer</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Train your own text classification model in the browser using TensorFlow.js.
            No servers or complicated setup required!
          </p>
        </div>
        
        <div className="mb-6">
          <div className="flex justify-center">
            <div className="bg-white rounded-full shadow-md inline-flex overflow-hidden">
              <button
                className={`px-4 py-2 flex items-center gap-1 ${
                  activeTab === 'dataset' 
                    ? 'bg-blue-600 text-white' 
                    : 'hover:bg-gray-100 text-gray-700'
                }`}
                onClick={() => setActiveTab('dataset')}
              >
                <Database size={18} />
                <span>Dataset</span>
              </button>
              
              <button
                className={`px-4 py-2 flex items-center gap-1 ${
                  activeTab === 'train' 
                    ? 'bg-blue-600 text-white' 
                    : 'hover:bg-gray-100 text-gray-700'
                }`}
                onClick={() => setActiveTab('train')}
              >
                <Cpu size={18} />
                <span>Train</span>
              </button>
              
              <button
                className={`px-4 py-2 flex items-center gap-1 ${
                  activeTab === 'test' 
                    ? 'bg-blue-600 text-white' 
                    : 'hover:bg-gray-100 text-gray-700'
                } ${
                  !modelTrained ? 'opacity-50 cursor-not-allowed' : ''
                }`}
                onClick={() => modelTrained && setActiveTab('test')}
                disabled={!modelTrained}
              >
                <TestTube size={18} />
                <span>Test</span>
              </button>
            </div>
          </div>
        </div>
        
        {!isInitialized ? (
          <div className="text-center p-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-600 rounded-full mb-4 animate-pulse">
              <Brain size={32} />
            </div>
            <p className="text-xl text-gray-700">Initializing TensorFlow.js...</p>
            <p className="text-gray-500">This may take a moment depending on your device.</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {activeTab === 'dataset' && (
              <>
                <div className="col-span-full">
                  <DatasetManager dataset={dataset} onDatasetChange={handleDatasetChange} />
                </div>
              </>
            )}
            
            {activeTab === 'train' && (
              <>
                <div className="md:col-span-2">
                  <ModelTrainer dataset={dataset} onModelTrained={handleModelTrained} />
                </div>
              </>
            )}
            
            {activeTab === 'test' && (
              <>
                <div className="md:col-span-2">
                  <ModelTester categories={dataset.categories} isTrained={modelTrained} />
                </div>
              </>
            )}
          </div>
        )}
      </main>
      
      <footer className="bg-gray-800 text-gray-400 py-4 text-center text-sm">
        <div className="container mx-auto">
          <p>Powered by TensorFlow.js and React. All processing happens in your browser.</p>
          <p className="mt-1">No data is sent to any server.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;