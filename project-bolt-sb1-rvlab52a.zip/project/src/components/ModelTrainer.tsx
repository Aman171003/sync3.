import React, { useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import { 
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Activity, BarChart, CheckCircle, XCircle, LineChart } from 'lucide-react';
import modelService from '../services/modelService';
import { Dataset, ModelMetrics } from '../types';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface ModelTrainerProps {
  dataset: Dataset;
  onModelTrained: () => void;
}

const ModelTrainer: React.FC<ModelTrainerProps> = ({ dataset, onModelTrained }) => {
  const [isTraining, setIsTraining] = useState(false);
  const [epochs, setEpochs] = useState(20);
  const [currentEpoch, setCurrentEpoch] = useState(0);
  const [metrics, setMetrics] = useState<ModelMetrics[]>([]);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const startTraining = async () => {
    if (dataset.examples.length < 10) {
      setError('Need at least 10 examples to train a model');
      return;
    }
    
    setIsTraining(true);
    setSuccess(false);
    setError(null);
    setMetrics([]);
    setCurrentEpoch(0);
    
    try {
      await modelService.train(dataset, epochs, {
        onProgress: (metrics: ModelMetrics) => {
          setCurrentEpoch(metrics.epoch + 1);
          setMetrics(prevMetrics => [...prevMetrics, metrics]);
        },
        onComplete: () => {
          setSuccess(true);
          onModelTrained();
        },
        onError: (err: Error) => {
          setError(err.message);
        }
      });
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('Unknown error occurred during training');
      }
    } finally {
      setIsTraining(false);
    }
  };

  const chartData = {
    labels: metrics.map(m => `Epoch ${m.epoch + 1}`),
    datasets: [
      {
        label: 'Accuracy',
        data: metrics.map(m => m.accuracy),
        fill: false,
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        borderColor: 'rgba(75, 192, 192, 1)',
        tension: 0.1
      },
      {
        label: 'Loss',
        data: metrics.map(m => m.loss),
        fill: false,
        backgroundColor: 'rgba(255, 99, 132, 0.2)',
        borderColor: 'rgba(255, 99, 132, 1)',
        tension: 0.1
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,
        max: 1.0
      }
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <h2 className="text-xl font-bold mb-4 text-gray-800">Model Training</h2>
      
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Training Epochs
        </label>
        <div className="flex items-center gap-2">
          <input
            type="range"
            min="5"
            max="50"
            value={epochs}
            onChange={(e) => setEpochs(parseInt(e.target.value))}
            className="w-full accent-blue-600"
            disabled={isTraining}
          />
          <span className="text-gray-700 font-medium w-12 text-center">{epochs}</span>
        </div>
      </div>
      
      <div className="mb-4">
        <button
          onClick={startTraining}
          disabled={isTraining || dataset.examples.length < 10}
          className={`w-full py-2 rounded-md ${
            isTraining 
              ? 'bg-gray-400 cursor-not-allowed' 
              : 'bg-blue-600 hover:bg-blue-700'
          } text-white font-medium transition-colors flex items-center justify-center gap-2`}
        >
          {isTraining ? (
            <>
              <Activity size={20} className="animate-pulse" />
              Training... ({currentEpoch}/{epochs})
            </>
          ) : (
            <>
              <BarChart size={20} />
              Train Model
            </>
          )}
        </button>
      </div>
      
      {error && (
        <div className="mb-4 p-3 bg-red-100 border border-red-300 text-red-800 rounded-md flex items-center gap-2">
          <XCircle size={20} />
          <span>{error}</span>
        </div>
      )}
      
      {success && (
        <div className="mb-4 p-3 bg-green-100 border border-green-300 text-green-800 rounded-md flex items-center gap-2">
          <CheckCircle size={20} />
          <span>Model trained successfully!</span>
        </div>
      )}
      
      {metrics.length > 0 && (
        <div className="mb-4">
          <h3 className="text-lg font-medium mb-2 flex items-center gap-1">
            <LineChart size={18} />
            Training Progress
          </h3>
          <div className="h-64">
            <Line data={chartData} options={chartOptions} />
          </div>
          
          <div className="mt-4 grid grid-cols-2 gap-4">
            <div className="bg-blue-50 p-3 rounded-md">
              <p className="text-sm text-blue-800 font-medium">Final Accuracy</p>
              <p className="text-xl font-bold text-blue-900">
                {(metrics[metrics.length - 1]?.accuracy * 100).toFixed(1)}%
              </p>
            </div>
            
            <div className="bg-purple-50 p-3 rounded-md">
              <p className="text-sm text-purple-800 font-medium">Final Loss</p>
              <p className="text-xl font-bold text-purple-900">
                {metrics[metrics.length - 1]?.loss.toFixed(4)}
              </p>
            </div>
          </div>
        </div>
      )}
      
      <div className="text-sm text-gray-500">
        <p>Recommendation: Train with at least 30 examples for better results.</p>
        <p>Current dataset: {dataset.examples.length} examples across {dataset.categories.length} categories.</p>
      </div>
    </div>
  );
};

export default ModelTrainer;