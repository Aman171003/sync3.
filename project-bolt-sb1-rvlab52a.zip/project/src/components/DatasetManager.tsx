import React, { useState } from 'react';
import { PlusCircle, Trash2, Edit, Save, X } from 'lucide-react';
import { Dataset, TrainingExample } from '../types';

interface DatasetManagerProps {
  dataset: Dataset;
  onDatasetChange: (updatedDataset: Dataset) => void;
}

const DatasetManager: React.FC<DatasetManagerProps> = ({ dataset, onDatasetChange }) => {
  const [newExample, setNewExample] = useState<Partial<TrainingExample>>({
    text: '',
    label: dataset.categories[0]
  });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const [editLabel, setEditLabel] = useState('');
  const [filter, setFilter] = useState('all');

  const handleAddExample = () => {
    if (!newExample.text) return;
    
    const updatedDataset = {
      ...dataset,
      examples: [
        ...dataset.examples,
        {
          id: Date.now().toString(),
          text: newExample.text,
          label: newExample.label || dataset.categories[0]
        }
      ]
    };
    
    onDatasetChange(updatedDataset);
    setNewExample({ text: '', label: dataset.categories[0] });
  };

  const handleDeleteExample = (id: string) => {
    const updatedDataset = {
      ...dataset,
      examples: dataset.examples.filter(example => example.id !== id)
    };
    
    onDatasetChange(updatedDataset);
  };

  const startEditing = (example: TrainingExample) => {
    setEditingId(example.id);
    setEditText(example.text);
    setEditLabel(example.label);
  };

  const cancelEditing = () => {
    setEditingId(null);
  };

  const saveEditing = () => {
    if (!editingId) return;
    
    const updatedDataset = {
      ...dataset,
      examples: dataset.examples.map(example => 
        example.id === editingId 
          ? { ...example, text: editText, label: editLabel }
          : example
      )
    };
    
    onDatasetChange(updatedDataset);
    setEditingId(null);
  };

  const filteredExamples = filter === 'all' 
    ? dataset.examples
    : dataset.examples.filter(ex => ex.label === filter);

  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <h2 className="text-xl font-bold mb-4 text-gray-800">Training Dataset</h2>
      
      <div className="mb-4">
        <div className="flex items-center gap-2 mb-2">
          <input
            type="text"
            value={newExample.text}
            onChange={(e) => setNewExample({ ...newExample, text: e.target.value })}
            placeholder="Enter a new example text..."
            className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          
          <select
            value={newExample.label}
            onChange={(e) => setNewExample({ ...newExample, label: e.target.value })}
            className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {dataset.categories.map(category => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
          
          <button
            onClick={handleAddExample}
            className="bg-blue-600 text-white p-2 rounded-md hover:bg-blue-700 transition-colors flex items-center"
            disabled={!newExample.text}
          >
            <PlusCircle size={20} />
          </button>
        </div>
      </div>
      
      <div className="mb-4">
        <div className="flex gap-2">
          <button
            className={`px-3 py-1 rounded-md ${
              filter === 'all' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'
            }`}
            onClick={() => setFilter('all')}
          >
            All ({dataset.examples.length})
          </button>
          
          {dataset.categories.map(category => (
            <button
              key={category}
              className={`px-3 py-1 rounded-md ${
                filter === category ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'
              }`}
              onClick={() => setFilter(category)}
            >
              {category} ({dataset.examples.filter(ex => ex.label === category).length})
            </button>
          ))}
        </div>
      </div>
      
      <div className="max-h-96 overflow-y-auto">
        {filteredExamples.length > 0 ? (
          <ul className="space-y-2">
            {filteredExamples.map(example => (
              <li 
                key={example.id} 
                className="border border-gray-200 rounded-md p-3 hover:bg-gray-50 transition-colors"
              >
                {editingId === example.id ? (
                  <div className="flex flex-col gap-2">
                    <input
                      type="text"
                      value={editText}
                      onChange={(e) => setEditText(e.target.value)}
                      className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    
                    <div className="flex items-center gap-2">
                      <select
                        value={editLabel}
                        onChange={(e) => setEditLabel(e.target.value)}
                        className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        {dataset.categories.map(category => (
                          <option key={category} value={category}>
                            {category}
                          </option>
                        ))}
                      </select>
                      
                      <button
                        onClick={saveEditing}
                        className="bg-green-600 text-white p-2 rounded-md hover:bg-green-700 transition-colors"
                      >
                        <Save size={16} />
                      </button>
                      
                      <button
                        onClick={cancelEditing}
                        className="bg-gray-600 text-white p-2 rounded-md hover:bg-gray-700 transition-colors"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-gray-800">{example.text}</p>
                      <span className={`inline-block mt-1 px-2 py-0.5 text-xs rounded-full ${
                        example.label === 'positive' ? 'bg-green-100 text-green-800' :
                        example.label === 'negative' ? 'bg-red-100 text-red-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {example.label}
                      </span>
                    </div>
                    
                    <div className="flex gap-1">
                      <button
                        onClick={() => startEditing(example)}
                        className="text-blue-600 hover:text-blue-800 p-1"
                      >
                        <Edit size={16} />
                      </button>
                      
                      <button
                        onClick={() => handleDeleteExample(example.id)}
                        className="text-red-600 hover:text-red-800 p-1"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                )}
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-gray-500 text-center py-4">No examples matching the selected filter.</p>
        )}
      </div>
      
      <div className="mt-4 text-sm text-gray-500">
        Total examples: {dataset.examples.length} | Training set: ~80% | Validation set: ~20%
      </div>
    </div>
  );
};

export default DatasetManager;