import React, { useState } from 'react';
import { Send, AlertCircle, Share2 } from 'lucide-react';
import modelService from '../services/modelService';
import { PredictionResult } from '../types';

interface ModelTesterProps {
  categories: string[];
  isTrained: boolean;
}

const ModelTester: React.FC<ModelTesterProps> = ({ categories, isTrained }) => {
  const [inputText, setInputText] = useState('');
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handlePredict = async () => {
    if (!inputText.trim() || !isTrained) return;
    
    setIsLoading(true);
    try {
      const result = await modelService.predict(inputText);
      setPrediction(result);
    } catch (error) {
      console.error('Prediction error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handlePredict();
    }
  };

  // Get color based on label
  const getLabelColor = (label: string) => {
    switch (label) {
      case 'positive':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'negative':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'neutral':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      default:
        return 'bg-blue-100 text-blue-800 border-blue-200';
    }
  };

  // Get color for confidence bar
  const getConfidenceColor = (confidence: number) => {
    if (confidence > 0.8) return 'bg-green-500';
    if (confidence > 0.5) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <h2 className="text-xl font-bold mb-4 text-gray-800">Test Your Model</h2>
      
      {!isTrained && (
        <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 text-yellow-800 rounded-md flex items-center gap-2">
          <AlertCircle size={20} />
          <span>Train your model first before testing</span>
        </div>
      )}
      
      <div className="mb-4">
        <textarea
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Enter text to classify..."
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 min-h-[80px]"
          disabled={!isTrained || isLoading}
        />
      </div>
      
      <div className="mb-4">
        <button
          onClick={handlePredict}
          disabled={!inputText.trim() || !isTrained || isLoading}
          className={`w-full py-2 rounded-md ${
            !inputText.trim() || !isTrained || isLoading
              ? 'bg-gray-400 cursor-not-allowed'
              : 'bg-blue-600 hover:bg-blue-700'
          } text-white font-medium transition-colors flex items-center justify-center gap-2`}
        >
          {isLoading ? 'Analyzing...' : (
            <>
              <Send size={18} />
              Classify Text
            </>
          )}
        </button>
      </div>
      
      {prediction && (
        <div className="mt-6 border border-gray-200 rounded-lg p-4 transition-all duration-300 ease-in-out">
          <h3 className="text-lg font-semibold mb-3">Prediction Result</h3>
          
          <div className="mb-4">
            <p className="text-gray-600 text-sm mb-2">Input text:</p>
            <p className="text-gray-900 bg-gray-50 p-2 rounded border border-gray-200">{prediction.text}</p>
          </div>
          
          <div className="mb-4">
            <p className="text-gray-600 text-sm mb-2">Prediction:</p>
            <div className="flex items-center gap-3">
              <span className={`px-3 py-1 rounded-full font-medium ${getLabelColor(prediction.predictedLabel)}`}>
                {prediction.predictedLabel}
              </span>
              <span className="text-gray-600">
                with {(prediction.confidence * 100).toFixed(1)}% confidence
              </span>
            </div>
          </div>
          
          <div>
            <p className="text-gray-600 text-sm mb-2">Confidence breakdown:</p>
            <div className="space-y-2">
              {prediction.allPredictions
                .sort((a, b) => b.confidence - a.confidence)
                .map(pred => (
                <div key={pred.label} className="flex items-center gap-2">
                  <span className="w-24 text-sm">{pred.label}:</span>
                  <div className="flex-1 bg-gray-200 rounded-full h-4 overflow-hidden">
                    <div 
                      className={`h-full ${getConfidenceColor(pred.confidence)}`}
                      style={{ width: `${pred.confidence * 100}%` }}
                    ></div>
                  </div>
                  <span className="text-sm font-medium w-14 text-right">
                    {(pred.confidence * 100).toFixed(1)}%
                  </span>
                </div>
              ))}
            </div>
          </div>
          
          <div className="mt-4 text-right">
            <button className="text-blue-600 text-sm flex items-center gap-1 hover:text-blue-800 ml-auto">
              <Share2 size={14} />
              Share result
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ModelTester;