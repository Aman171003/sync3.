import React from 'react';
import { Brain } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Brain size={32} className="text-white" />
          <div>
            <h1 className="text-xl font-bold">QuickAI</h1>
            <p className="text-xs text-blue-100">Text Classification Trainer</p>
          </div>
        </div>
        <div className="text-sm">
          <span className="bg-blue-700 px-2 py-1 rounded text-blue-100">
            TensorFlow.js
          </span>
        </div>
      </div>
    </header>
  );
};

export default Header;