import { Dataset } from '../types';

export const defaultCategories = ['positive', 'negative', 'neutral'];

export const sampleDataset: Dataset = {
  name: 'Sentiment Analysis',
  categories: defaultCategories,
  examples: [
    { id: '1', text: 'I love this product, it works amazingly!', label: 'positive' },
    { id: '2', text: 'Great service and friendly staff.', label: 'positive' },
    { id: '3', text: 'This exceeded my expectations.', label: 'positive' },
    { id: '4', text: 'Wonderful experience, would recommend!', label: 'positive' },
    { id: '5', text: 'Best purchase I have made in years.', label: 'positive' },
    { id: '6', text: 'Happy with the results.', label: 'positive' },
    { id: '7', text: 'This app has been so helpful.', label: 'positive' },
    { id: '8', text: 'The quality is outstanding.', label: 'positive' },
    { id: '9', text: 'I regret buying this.', label: 'negative' },
    { id: '10', text: 'Poor quality and overpriced.', label: 'negative' },
    { id: '11', text: 'Terrible customer service.', label: 'negative' },
    { id: '12', text: 'This was a waste of money.', label: 'negative' },
    { id: '13', text: 'Disappointed with the results.', label: 'negative' },
    { id: '14', text: 'Would not recommend to anyone.', label: 'negative' },
    { id: '15', text: 'Failed to meet my expectations.', label: 'negative' },
    { id: '16', text: 'The product broke after one week.', label: 'negative' },
    { id: '17', text: 'It was okay, nothing special.', label: 'neutral' },
    { id: '18', text: 'Average performance for the price.', label: 'neutral' },
    { id: '19', text: 'Neither good nor bad, just adequate.', label: 'neutral' },
    { id: '20', text: 'Does what it claims, nothing more.', label: 'neutral' },
    { id: '21', text: 'I have mixed feelings about this.', label: 'neutral' },
    { id: '22', text: 'Some features are good, others not so much.', label: 'neutral' },
    { id: '23', text: 'It serves its purpose.', label: 'neutral' },
    { id: '24', text: 'Reasonable quality for the price.', label: 'neutral' },
  ]
};