export interface TrainingExample {
  id: string;
  text: string;
  label: string;
}

export interface Dataset {
  name: string;
  categories: string[];
  examples: TrainingExample[];
}

export interface ModelInfo {
  name: string;
  description: string;
  categories: string[];
  wordCount: number;
  accuracy: number;
  created: string;
  trainedExamples: number;
}

export interface ModelMetrics {
  accuracy: number;
  loss: number;
  epoch: number;
}

export interface PredictionResult {
  text: string;
  predictedLabel: string;
  confidence: number;
  allPredictions: {
    label: string;
    confidence: number;
  }[];
}